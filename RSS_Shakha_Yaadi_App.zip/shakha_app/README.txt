╔══════════════════════════════════════════════════════════╗
║           RSS શાખા યાદી — App Instructions             ║
║         RSS SHAKHA YAADI - HOW TO USE                   ║
╚══════════════════════════════════════════════════════════╝

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 ADMIN LOGIN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ID       : vikram
  Password : shakha2026

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 METHOD 1 — EASIEST (No Python needed)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  1. Double-click: shakha_yaadi.html
  2. It opens in your browser (Chrome / Edge)
  3. Login and use!

  ✅ Works on any laptop/PC
  ✅ No installation needed
  ✅ Share this file with anyone — they double-click and use

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 METHOD 2 — WINDOWS (Python launcher)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  1. Make sure Python is installed
     Download: https://python.org/downloads
     ⚠️ Check "Add Python to PATH" during install
  2. Double-click: Windows_Open_App.bat
  3. App opens in your browser automatically

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 METHOD 3 — MAC / LINUX
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  1. Open Terminal
  2. Type: bash Mac_Linux_Open_App.sh
  3. App opens automatically

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 APP FEATURES | એપ ની સુવિધા
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  ✅ સભ્ય ઉમેરો (Add members)
  ✅ ફોટો અપલોડ (Photo upload)
  ✅ ગુજરાતી ટ્રાન્સલેશન (Auto Gujarati)
  ✅ CSV ડાઉનલોડ (Download CSV for Excel)
  ✅ Admin Notifications
  ✅ સર્ચ અને ફિલ્ટર (Search & filter)
  ✅ ઓફલાઇન કામ કરે (Works offline)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 SHARING WITH OTHERS | બીજાને મોકલો
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  • Share the entire "RSS_Shakha_App" folder
  • Or just send "shakha_yaadi.html" alone
  • WhatsApp / Email / Google Drive — all work
  • Recipient double-clicks the .html file to use

  ⚠️ NOTE: Each person's data is stored on THEIR
     own device. Data does not sync automatically.
     For shared data, export CSV and share that file.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 MADE WITH ❤️ FOR RSS SHAKHA
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
