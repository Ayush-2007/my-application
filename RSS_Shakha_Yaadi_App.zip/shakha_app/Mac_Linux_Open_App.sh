#!/bin/bash
echo "Starting RSS Shakha Yaadi App..."
python3 RSS_Shakha_Open.py
