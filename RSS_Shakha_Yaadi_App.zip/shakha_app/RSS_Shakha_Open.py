#!/usr/bin/env python3
"""
RSS Shakha Yaadi - App Launcher
Double click this file to open the app.
Python must be installed: https://python.org
"""
import os
import sys
import webbrowser
import http.server
import threading
import time

PORT = 8765
DIR = os.path.dirname(os.path.abspath(__file__))

class SilentHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIR, **kwargs)
    def log_message(self, format, *args):
        pass  # Silent - no console spam

def start_server():
    server = http.server.HTTPServer(('localhost', PORT), SilentHandler)
    server.serve_forever()

if __name__ == '__main__':
    # Start server in background
    t = threading.Thread(target=start_server, daemon=True)
    t.start()
    time.sleep(1)  # Wait for server to start

    # Open in browser
    url = f'http://localhost:{PORT}/shakha_yaadi.html'
    print(f"Opening RSS Shakha Yaadi App...")
    print(f"URL: {url}")
    webbrowser.open(url)

    print("\nApp is running. Close this window to stop the app.")
    print("Press Ctrl+C to exit.")
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("App closed.")
        sys.exit(0)
