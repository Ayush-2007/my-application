@echo off
title RSS Shakha Yaadi App
echo.
echo  ==========================================
echo   RSS Shakha Yaadi - Starting...
echo  ==========================================
echo.
python RSS_Shakha_Open.py
if %errorlevel% neq 0 (
    echo.
    echo  ERROR: Python not found!
    echo  Please install Python from https://python.org
    echo  Then try again.
    echo.
    pause
)
